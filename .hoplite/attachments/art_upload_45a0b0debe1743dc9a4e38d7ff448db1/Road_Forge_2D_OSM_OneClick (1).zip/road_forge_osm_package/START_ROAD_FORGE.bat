@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 launch_road_forge.py
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python launch_road_forge.py
  ) else (
    echo Python was not found. Install Python 3 from https://www.python.org/downloads/ and retry.
    pause
  )
)
