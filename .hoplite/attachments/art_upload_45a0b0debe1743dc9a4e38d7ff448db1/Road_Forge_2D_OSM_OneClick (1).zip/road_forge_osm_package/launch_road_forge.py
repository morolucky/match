from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote_plus
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
import json
import webbrowser

ROOT = Path(__file__).resolve().parent
PAGE = "Road_Forge_2D_OSM.html"
OVERPASS_ENDPOINTS = (
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.nchc.org.tw/api/interpreter",
)

class RoadForgeHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path.split("?", 1)[0] != "/api/overpass":
            self._send_json(404, {"error": "Unknown local API endpoint."})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 2_000_000:
                self._send_json(400, {"error": "Invalid or oversized request body."})
                return
            form = parse_qs(self.rfile.read(length).decode("utf-8", errors="replace"), keep_blank_values=True)
            query = form.get("data", [""])[0].strip()
            if not query or len(query) > 1_000_000:
                self._send_json(400, {"error": "Missing or oversized Overpass query."})
                return

            errors = []
            for endpoint in OVERPASS_ENDPOINTS:
                try:
                    request = Request(
                        endpoint,
                        data=("data=" + quote_plus(query)).encode("utf-8"),
                        headers={
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "User-Agent": "RoadForge2D/1.1 (local road visualization tool)",
                            "Accept": "application/json",
                        },
                        method="POST",
                    )
                    with urlopen(request, timeout=55) as response:
                        upstream = response.read(25_000_000)
                    data = json.loads(upstream.decode("utf-8"))
                    if not isinstance(data, dict) or not isinstance(data.get("elements"), list):
                        raise ValueError("Unexpected response from Overpass service")
                    body = json.dumps(data).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(body)
                    return
                except HTTPError as exc:
                    errors.append(f"{endpoint}: HTTP {exc.code}")
                except (URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError) as exc:
                    errors.append(f"{endpoint}: {str(exc)[:180]}")
            self._send_json(502, {
                "error": "All Overpass servers failed. Check internet and try again later, or reduce the import radius. Details: " + " | ".join(errors)
            })
        except Exception as exc:
            self._send_json(500, {"error": "Local proxy error: " + str(exc)[:300]})

if not (ROOT / PAGE).is_file():
    raise SystemExit(f"Missing {PAGE}. Keep the launcher and HTML file in the same folder.")

server = None
for port in range(8765, 8800):
    try:
        server = ThreadingHTTPServer(("127.0.0.1", port), RoadForgeHandler)
        break
    except OSError:
        continue

if server is None:
    raise SystemExit("Could not find a free local port between 8765 and 8799.")

url = f"http://127.0.0.1:{server.server_port}/{PAGE}"
print("Road Forge is running locally.")
print("URL:", url)
print("OSM requests will be relayed by the local Python server to avoid browser CORS restrictions.")
print("Keep this window open while using the program. Press Ctrl+C to stop the server.")
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    print("\nStopping Road Forge server…")
finally:
    server.server_close()
