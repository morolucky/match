@echo off
cd /d "%~dp0"
py launch_studio.py 2>nul || python launch_studio.py
pause
