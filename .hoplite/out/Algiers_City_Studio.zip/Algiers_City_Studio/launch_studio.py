#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Launches the Algiers City Studio on a local server and opens the browser."""
import http.server, socketserver, webbrowser, os, threading
os.chdir(os.path.dirname(os.path.abspath(__file__)))
PORT = 8420
class H(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()
    def log_message(self, *a): pass
with socketserver.TCPServer(("127.0.0.1", PORT), H) as httpd:
    url = f"http://127.0.0.1:{PORT}/index.html"
    print("Algiers City Studio:", url)
    print("CTRL+C للإيقاف")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try: httpd.serve_forever()
    except KeyboardInterrupt: pass
